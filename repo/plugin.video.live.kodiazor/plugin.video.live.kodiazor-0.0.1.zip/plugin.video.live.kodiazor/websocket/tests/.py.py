[{"url": "http://kodiazorteam.website/submenuiptv.xml", "fanart": ".\\fanart.jpg", "title": "kodiazor"}]
