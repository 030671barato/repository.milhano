import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL3N1cHJlbWFjeS5vcmcudWsvRWxla3RyYV9WYXVsdC9MSVZFVFYvTWFpbkhvbWUueG1s')
addon = xbmcaddon.Addon('plugin.video.Elektra_Vault')