import xbmcaddon

MainBase = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3V1RDJpSFRy'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.aceboxtv')