import xbmcaddon

MainBase = 'http://bit.ly/2DQvNzu'
addon = xbmcaddon.Addon('plugin.video.LisboaStreams')