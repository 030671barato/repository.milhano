# plugin.image.bancasapo

Daily portuguese newspapper covers in Kodi

* Screenshots

![Screenshot screensaver](https://github.com/enen92/plugin.image.bancasapo/blob/master/resources/images/screenshot-01.jpg?raw=true)

![Screenshot screensaver](https://github.com/enen92/plugin.image.bancasapo/blob/master/resources/images/screenshot-02.jpg?raw=true)

![Screenshot screensaver](https://github.com/enen92/plugin.image.bancasapo/blob/master/resources/images/screenshot-03.jpg?raw=true)

![Screenshot screensaver](https://github.com/enen92/plugin.image.bancasapo/blob/master/resources/images/screenshot-04.jpg?raw=true)
